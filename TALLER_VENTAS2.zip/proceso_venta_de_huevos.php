<?php
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$cantidad =$_POST['cantidad'];

$valor_huevos = 350;


$subtotal =$cantidad* $valor_huevos;
if ($edad > 49 and $edad <71) {
    $descuento =(0.2*$subtotal);
    $subtotal =$subtotal - $descuento;
}


echo "<h2>señor $nombre usted debe pagar: $subtotal pesos </h2>";